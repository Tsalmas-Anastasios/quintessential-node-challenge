export interface PostGraphqlQueryParams {

    user_id?: string;
    post_id?: string;
    page?: number;
    limit?: number;
    order_by_date?: string;
}
