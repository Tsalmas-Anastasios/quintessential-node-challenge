export interface PostCommentGraphqlQueryParams {

    post_id?: string;
    user_id?: string;
    page?: number;
    limit?: number;

}
