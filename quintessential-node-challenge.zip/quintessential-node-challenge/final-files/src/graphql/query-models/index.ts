export { PostGraphqlQueryParams } from './PostQuery';
export { PostCommentGraphqlQueryParams } from './PostCommentQuery';
