# schillz-backend

- Node version: 18

before you run the BackEnd locally, run these commands:
1. delete the "graphql" dependency from the package.json
2. npm install
3. npm install graphql
4. npm run grunt
5. (from VSCode) Run & Debug or (from terminal) npm run nodemon# schillz-backend
# quintessential-node-challenge
